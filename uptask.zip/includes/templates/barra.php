<div class="barra">
    <a href="index.php"><h1>UpTask - Administración de Proyectos</h1></a>
    <a href="login.php?cerrar_sesion=true">Cerrar Sesión</a>    <!--Enviamos por medio del metodo GET la informacion para cerrar la sesion-->
</div>